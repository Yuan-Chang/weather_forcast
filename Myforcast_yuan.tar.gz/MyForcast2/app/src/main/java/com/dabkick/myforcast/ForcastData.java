package com.dabkick.myforcast;

/**
 * Created by developer3 on 12/19/15.
 */
public class ForcastData {

    String title;
    String summary;
    String temparature;
    String max_temparature;
    String min_temparature;

    public ForcastData(String title) {
        this.title = title;
    }

}
